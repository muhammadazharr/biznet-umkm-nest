export class Faq {}

export class Produk {}

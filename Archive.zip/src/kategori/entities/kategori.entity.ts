export class Kategori {}

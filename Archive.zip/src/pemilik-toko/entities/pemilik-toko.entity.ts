export class PemilikToko {}

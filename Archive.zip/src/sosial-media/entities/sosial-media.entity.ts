export class SosialMedia {}

export class Pendaftar {}

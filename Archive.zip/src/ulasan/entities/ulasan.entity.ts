export class Ulasan {}
